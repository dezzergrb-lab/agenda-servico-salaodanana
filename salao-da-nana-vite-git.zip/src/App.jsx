import React, { useEffect, useMemo, useState } from "react";
import {
  Brush,
  Droplets,
  Wind,
  Palette,
  FlaskConical,
  Sparkles,
  Waves,
  Atom,
  Scissors,
  Layers,
  MoveHorizontal,
  Wrench,
} from "lucide-react";

// Salão da Naná — App de Agendamento (SPA)
// - Seleção de serviços com ícones e cores vivas
// - Calendário clicável (mobile-first, vertical, sem rolagem horizontal)
// - Horários em intervalos de 1h30, de 08:00 até 18:00 (último início às 17:00)
// - Bloqueio de dia/horário já confirmados (persistência localStorage)
// - Envio da confirmação via WhatsApp: +55 34 99774-1680
// Observação: este exemplo é client-side. Para múltiplos usuários reais,
// recomenda-se backend com banco de dados.

const SERVICES = [
  { key: "Escova", Icon: Brush, iconBg: "bg-pink-100 text-pink-700 border-pink-300" },
  { key: "Hidratação", Icon: Droplets, iconBg: "bg-cyan-100 text-cyan-700 border-cyan-300" },
  { key: "Relaxamento", Icon: Wind, iconBg: "bg-sky-100 text-sky-700 border-sky-300" },
  { key: "Coloração", Icon: Palette, iconBg: "bg-violet-100 text-violet-700 border-violet-300" },
  { key: "Química", Icon: FlaskConical, iconBg: "bg-amber-100 text-amber-700 border-amber-300" },
  { key: "Maquiagem", Icon: Sparkles, iconBg: "bg-rose-100 text-rose-700 border-rose-300" },
  { key: "Penteados", Icon: Waves, iconBg: "bg-lime-100 text-lime-700 border-lime-300" },
  { key: "Ozonoterapia", Icon: Atom, iconBg: "bg-emerald-100 text-emerald-700 border-emerald-300" },
  { key: "Corte", Icon: Scissors, iconBg: "bg-red-100 text-red-700 border-red-300" },
  { key: "Mechas", Icon: Layers, iconBg: "bg-fuchsia-100 text-fuchsia-700 border-fuchsia-300" },
  { key: "Alongamento Mega Hair", Icon: MoveHorizontal, iconBg: "bg-orange-100 text-orange-700 border-orange-300" },
  { key: "Manutenção", Icon: Wrench, iconBg: "bg-teal-100 text-teal-700 border-teal-300" },
];

const SLOT_MINUTES = 90; // 1h30
const START_HOUR = 8; // 08:00
const END_HOUR = 18; // 18:00 (limite de exibição do último horário, último início às 17:00)

function toKey(date) {
  // yyyy-mm-dd
  const y = date.getFullYear();
  const m = String(date.getMonth() + 1).padStart(2, "0");
  const d = String(date.getDate()).padStart(2, "0");
  return `${y}-${m}-${d}`;
}

function formatDateBR(date) {
  return date.toLocaleDateString("pt-BR", {
    weekday: "long",
    day: "2-digit",
    month: "long",
    year: "numeric",
  });
}

function formatTime(h, min = 0) {
  return `${String(h).padStart(2, "0")}:${String(min).padStart(2, "0")}`;
}

function generateSlots() {
  const slots = [];
  let minutes = START_HOUR * 60;
  // Gerar inícios até que o próximo passe do limite de 18:00.
  const limit = END_HOUR * 60;
  while (minutes <= limit) {
    const h = Math.floor(minutes / 60);
    const m = minutes % 60;
    slots.push(formatTime(h, m));
    minutes += SLOT_MINUTES; // 90min
  }
  // Resultado esperado: 08:00, 09:30, 11:00, 12:30, 14:00, 15:30, 17:00
  // (o próximo seria 18:30 e não entra por passar do limite)
  return slots.filter((t) => t <= "17:00");
}

function startOfMonth(date) {
  return new Date(date.getFullYear(), date.getMonth(), 1);
}

// Geração estável de grade mensal: 6 semanas (42 dias) começando na segunda-feira
function buildCalendarGrid(viewDate) {
  const first = startOfMonth(viewDate);
  const start = new Date(first);
  const mondayOffset = (first.getDay() + 6) % 7; // 0..6 (segunda = 0)
  start.setDate(first.getDate() - mondayOffset);

  const days = [];
  for (let i = 0; i < 42; i++) {
    const d = new Date(start);
    d.setDate(start.getDate() + i);
    days.push({ date: d, outside: d.getMonth() !== viewDate.getMonth() });
  }
  return days;
}

// Persistência simples em localStorage
function loadBookings() {
  try {
    const raw = localStorage.getItem("nanabeauty_bookings");
    return raw ? JSON.parse(raw) : {};
  } catch (e) {
    return {};
  }
}

function saveBookings(obj) {
  localStorage.setItem("nanabeauty_bookings", JSON.stringify(obj));
}

// ===== WhatsApp helpers =====
function buildWaText(name, phone, services, dateObj, time, notes) {
  const nameStr = name && name.trim() ? name.trim() : "cliente";
  const phoneStr = phone && phone.trim() ? phone.trim() : "-";
  const servicesStr = (services && services.length ? services.join(", ") : "-");
  const dateStr = dateObj ? formatDateBR(dateObj) : "-";
  const timeStr = time || "-";
  const notesStr = notes && notes.trim() ? `Observações: ${notes.trim()}\n` : "";
  // IMPORTANTE: manter tudo neste template literal com backticks para
  // evitar erros de interpolação (como ReferenceError: $1 is not defined)
  return (
    `Olá, sou ${nameStr}.\n` +
    `Meu telefone: ${phoneStr}.\n` +
    `Agendei no *Salão da Naná* os serviços: ${servicesStr}\n` +
    `Para: ${dateStr} às ${timeStr}.\n` +
    notesStr +
    `Pode confirmar, por favor?`
  );
}

function buildWaLink(number, message) {
  return `https://wa.me/${number}?text=${encodeURIComponent(message)}`;
}

export default function App() {
  const [selectedServices, setSelectedServices] = useState([]);
  const [notes, setNotes] = useState("");
  const [clientName, setClientName] = useState("");
  const [clientPhone, setClientPhone] = useState("");

  const [viewDate, setViewDate] = useState(() => {
    const d = new Date();
    d.setHours(0, 0, 0, 0);
    return d;
  });
  const [selectedDate, setSelectedDate] = useState(null);
  const [selectedTime, setSelectedTime] = useState(null);

  const [bookings, setBookings] = useState({});
  const [confirmed, setConfirmed] = useState(false);

  useEffect(() => {
    setBookings(loadBookings());
  }, []);

  useEffect(() => {
    saveBookings(bookings);
  }, [bookings]);

  const slots = useMemo(() => generateSlots(), []);
  const calendarDays = useMemo(() => buildCalendarGrid(viewDate), [viewDate]);
  const todayKey = useMemo(() => toKey(new Date()), []);

  const selectedDateKey = selectedDate ? toKey(selectedDate) : null;
  const bookedForDay = selectedDateKey && bookings[selectedDateKey] ? bookings[selectedDateKey] : [];

  const availableSlots = useMemo(() => {
    if (!selectedDateKey) return [];
    const booked = new Set(bookedForDay || []);
    return slots.map((s) => ({ time: s, available: !booked.has(s) }));
  }, [slots, bookedForDay, selectedDateKey]);

  // Dia está "lotado" se todos os horários do dia estiverem ocupados
  function isDayFullyBooked(date) {
    const key = toKey(date);
    const dayBooked = bookings[key] || [];
    return dayBooked.length >= slots.length;
  }

  function isPast(date) {
    const now = new Date();
    now.setHours(0, 0, 0, 0);
    return date < now;
  }

  function nextMonth() {
    const d = new Date(viewDate);
    d.setMonth(d.getMonth() + 1);
    setViewDate(d);
  }
  function prevMonth() {
    const d = new Date(viewDate);
    d.setMonth(d.getMonth() - 1);
    setViewDate(d);
  }

  function toggleService(service) {
    setSelectedServices((prev) =>
      prev.includes(service) ? prev.filter((s) => s !== service) : [...prev, service]
    );
  }

  function handleConfirm() {
    if (selectedServices.length === 0) {
      alert("Selecione pelo menos um serviço.");
      return;
    }
    if (!selectedDate || !selectedTime) {
      alert("Escolha o dia e o horário.");
      return;
    }
    if (!clientName || !clientPhone) {
      alert("Informe seu nome e telefone.");
      return;
    }

    const key = toKey(selectedDate);
    const dayBooked = new Set(bookings[key] || []);
    if (dayBooked.has(selectedTime)) {
      alert("Este horário acabou de ficar indisponível. Por favor, escolha outro.");
      return;
    }

    const updated = { ...bookings, [key]: [...(bookings[key] || []), selectedTime] };
    setBookings(updated);
    setConfirmed(true);
  }

  function resetAll() {
    setSelectedServices([]);
    setNotes("");
    setClientName("");
    setClientPhone("");
    setSelectedDate(null);
    setSelectedTime(null);
    setConfirmed(false);
  }

  const displayMonth = viewDate.toLocaleDateString("pt-BR", { month: "long", year: "numeric" });

  const whatsappNumber = "5534997741680"; // +55 34 99774-1680
  const waText = buildWaText(
    clientName,
    clientPhone,
    selectedServices,
    selectedDate,
    selectedTime,
    notes
  );
  const waLink = buildWaLink(whatsappNumber, waText);
  const waTestLink = buildWaLink(
    whatsappNumber,
    "Teste de agendamento do Salão da Naná — este é um envio de teste."
  );

  return (
    <>
      <div className="min-h-screen w-full overflow-x-hidden bg-gradient-to-b from-fuchsia-50 via-rose-50 to-amber-50 text-slate-800">
        <header className="sticky top-0 z-10 backdrop-blur bg-white/70 border-b border-rose-100">
          <div className="max-w-5xl mx-auto px-4 py-4 flex items-center justify-between">
            <h1 className="text-2xl md:text-3xl font-bold">
              Salão da <span className="text-rose-600">Naná</span>
            </h1>
            <span className="hidden sm:inline text-sm text-slate-500">Agendamentos com confirmação via WhatsApp</span>
          </div>
        </header>

        <main className="max-w-5xl mx-auto px-4 py-6 grid gap-6 grid-cols-1 md:grid-cols-2">
          {/* Coluna: Serviços */}
          <section className="bg-white rounded-2xl shadow-sm border border-rose-100 p-5 max-w-full">
            <h2 className="text-xl font-semibold mb-4">1) Escolha os serviços</h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {SERVICES.map(({ key, Icon, iconBg }) => {
                const active = selectedServices.includes(key);
                return (
                  <label
                    key={key}
                    className={`group w-full break-words flex items-center gap-3 p-3 rounded-xl border cursor-pointer transition ${
                      active
                        ? "border-rose-400 bg-gradient-to-r from-fuchsia-50 to-rose-50 ring-2 ring-rose-200"
                        : "border-slate-200 hover:border-rose-200"
                    }`}
                  >
                    <input
                      type="checkbox"
                      className="accent-rose-600 sr-only"
                      checked={active}
                      onChange={() => toggleService(key)}
                    />
                    <span className={`p-2 rounded-lg border ${iconBg}`}>
                      <Icon className="w-5 h-5" />
                    </span>
                    <span className="font-medium">{key}</span>
                  </label>
                );
              })}
            </div>

            <div className="mt-4">
              <label className="block text-sm font-medium mb-1">Observações (opcional)</label>
              <textarea
                className="w-full rounded-xl border border-slate-200 p-3 focus:outline-none focus:ring-2 focus:ring-rose-300"
                rows={3}
                placeholder="Ex.: cabelo longo, maquiagem para evento, etc."
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
              />
            </div>
          </section>

          {/* Coluna: Calendário */}
          <section className="bg-white rounded-2xl shadow-sm border border-rose-100 p-5 max-w-full">
            <h2 className="text-xl font-semibold mb-4">2) Escolha o dia</h2>

            <div className="flex items-center justify-between mb-3">
              <button onClick={prevMonth} className="px-3 py-2 rounded-lg border border-slate-200 hover:bg-slate-50">
                ← Mês anterior
              </button>
              <div className="font-medium">{displayMonth}</div>
              <button onClick={nextMonth} className="px-3 py-2 rounded-lg border border-slate-200 hover:bg-slate-50">
                Próximo mês →
              </button>
            </div>

            <div className="grid grid-cols-7 text-center text-xs font-semibold text-slate-500">
              {["Seg", "Ter", "Qua", "Qui", "Sex", "Sáb", "Dom"].map((w) => (
                <div key={w} className="py-2">
                  {w}
                </div>
              ))}
            </div>

            <div className="grid grid-cols-7 gap-1">
              {calendarDays.map(({ date, outside }, idx) => {
                const key = toKey(date);
                const disabled = outside || isPast(date) || isDayFullyBooked(date);
                const isSelected = selectedDate && toKey(selectedDate) === key;
                const isToday = key === todayKey;
                return (
                  <button
                    key={idx}
                    disabled={disabled}
                    onClick={() => setSelectedDate(date)}
                    className={
                      `aspect-square rounded-xl text-sm border transition flex items-center justify-center ` +
                      (disabled
                        ? "bg-slate-50 text-slate-300 border-slate-200 cursor-not-allowed"
                        : isSelected
                        ? "bg-rose-600 text-white border-rose-600"
                        : "bg-white hover:bg-rose-50 border-slate-200") +
                      (isToday && !disabled && !isSelected ? " ring-1 ring-rose-300" : "")
                    }
                    title={
                      disabled
                        ? outside
                          ? "Dia fora do mês"
                          : isPast(date)
                          ? "Dia passado"
                          : "Sem horários disponíveis"
                        : formatDateBR(date)
                    }
                  >
                    {date.getDate()}
                  </button>
                );
              })}
            </div>
          </section>

          {/* Coluna: Horários */}
          <section className="bg-white rounded-2xl shadow-sm border border-rose-100 p-5 max-w-full">
            <h2 className="text-xl font-semibold mb-4">3) Escolha o horário</h2>
            {!selectedDate && <p className="text-slate-500 text-sm">Selecione primeiro um dia no calendário.</p>}

            {selectedDate && (
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                {availableSlots.map(({ time, available }) => (
                  <button
                    key={time}
                    disabled={!available}
                    onClick={() => setSelectedTime(time)}
                    className={
                      `px-3 py-2 rounded-xl border text-sm transition ` +
                      (!available
                        ? "bg-slate-50 text-slate-300 border-slate-200 cursor-not-allowed"
                        : selectedTime === time
                        ? "bg-rose-600 text-white border-rose-600"
                        : "bg-white hover:bg-rose-50 border-slate-200")
                    }
                  >
                    {time}
                  </button>
                ))}
              </div>
            )}
          </section>

          {/* Coluna: Confirmação */}
          <section className="bg-white rounded-2xl shadow-sm border border-rose-100 p-5 max-w-full">
            <h2 className="text-xl font-semibold mb-4">4) Confirmar</h2>

            <div className="space-y-2 text-sm">
              <div>
                <span className="font-medium">Serviços:</span> {selectedServices.length ? selectedServices.join(", ") : "—"}
              </div>
              <div>
                <span className="font-medium">Dia:</span> {selectedDate ? formatDateBR(selectedDate) : "—"}
              </div>
              <div>
                <span className="font-medium">Horário:</span> {selectedTime || "—"}
              </div>
              {notes && (
                <div>
                  <span className="font-medium">Observações:</span> {notes}
                </div>
              )}
              {clientName && (
                <div>
                  <span className="font-medium">Cliente:</span> {clientName}
                </div>
              )}
              {clientPhone && (
                <div>
                  <span className="font-medium">Telefone:</span> {clientPhone}
                </div>
              )}
            </div>

            {/* Dados do cliente */}
            <div className="mt-4 grid md:grid-cols-2 gap-3">
              <div>
                <label className="block text-sm font-medium mb-1">Seu nome</label>
                <input
                  className="w-full rounded-xl border border-slate-200 p-3 focus:outline-none focus:ring-2 focus:ring-rose-300"
                  placeholder="Seu nome"
                  value={clientName}
                  onChange={(e) => setClientName(e.target.value)}
                />
              </div>
              <div>
                <label className="block text-sm font-medium mb-1">Seu telefone</label>
                <input
                  className="w-full rounded-xl border border-slate-200 p-3 focus:outline-none focus:ring-2 focus:ring-rose-300"
                  placeholder="(DDD) 9 9999-9999"
                  value={clientPhone}
                  onChange={(e) => setClientPhone(e.target.value)}
                />
              </div>
            </div>

            {!confirmed ? (
              <div className="mt-4 flex flex-wrap items-center gap-3">
                <button
                  onClick={handleConfirm}
                  className="px-4 py-3 rounded-xl bg-gradient-to-r from-rose-600 to-fuchsia-600 text-white font-medium shadow hover:from-rose-700 hover:to-fuchsia-700"
                >
                  Confirmar agendamento
                </button>
                <a
                  href={waTestLink}
                  target="_blank"
                  rel="noreferrer"
                  className="px-4 py-3 rounded-xl border border-emerald-200 hover:bg-emerald-50"
                  title="Abre uma conversa de teste no WhatsApp (sem precisar preencher o formulário)"
                >
                  Link de teste (WhatsApp)
                </a>
                <button onClick={resetAll} className="px-4 py-3 rounded-xl border border-slate-200 hover:bg-slate-50">
                  Limpar
                </button>
              </div>
            ) : (
              <div className="mt-4 space-y-3">
                <div className="p-4 rounded-xl bg-green-50 border border-green-200 text-green-800">
                  ✅ Agendamento confirmado! O dia e horário escolhidos agora estão indisponíveis para novos agendamentos.
                </div>
                <a
                  href={waLink}
                  target="_blank"
                  rel="noreferrer"
                  className="inline-flex items-center justify-center gap-2 px-4 py-3 rounded-xl bg-emerald-600 text-white font-medium shadow hover:bg-emerald-700"
                >
                  Enviar confirmação no WhatsApp (34 99774-1680)
                </a>
                <button onClick={resetAll} className="ml-2 px-4 py-3 rounded-xl border border-slate-200 hover:bg-slate-50">
                  Novo agendamento
                </button>
              </div>
            )}
          </section>
        </main>

        <footer className="max-w-5xl mx-auto px-4 pb-10 text-center text-xs text-slate-500">
          <p>© {new Date().getFullYear()} Salão da Naná — Agendamento simples (demo).</p>
          <p>Horários em intervalos de 1h30, das 08:00 às 18:00 (último início às 17:00).</p>
        </footer>
      </div>
    </>
  );
}

// ------------------------------
// TESTES SIMPLES (executam no navegador — console)
// ------------------------------
(function runBasicTests() {
  try {
    const slots = generateSlots();
    const expected = ["08:00", "09:30", "11:00", "12:30", "14:00", "15:30", "17:00"];
    console.assert(Array.isArray(slots), "generateSlots deve retornar array");
    console.assert(slots.length === expected.length, `slots deve ter ${expected.length} itens, veio ${slots.length}`);
    console.assert(slots.every((s, i) => s === expected[i]), `slots esperado: ${expected.join(", ")} | obtido: ${slots.join(", ")}`);

    const k = toKey(new Date(2025, 0, 5));
    console.assert(k === "2025-01-05", `toKey incorreto, obtido ${k}`);

    const grid = buildCalendarGrid(new Date(2025, 0, 1));
    console.assert(grid.length === 42, `grade do calendário deve ter 42 dias, veio ${grid.length}`);
    console.log("✅ Testes básicos passaram (generateSlots, toKey, buildCalendarGrid).");
  } catch (err) {
    console.warn("⚠️ Falha em testes básicos:", err);
  }
})();

// ------------------------------
// TESTES ADICIONAIS (não alteram os existentes)
// ------------------------------
(function runAdditionalTests() {
  try {
    const msg = buildWaText(
      "Maria",
      "(34) 99999-9999",
      ["Escova", "Coloração"],
      new Date(2025, 0, 5),
      "11:00",
      "Cabelo longo"
    );
    console.assert(typeof msg === "string" && msg.includes("Salão da Naná"), "buildWaText deve gerar string com o nome do salão");

    const link = buildWaLink("5534997741680", msg);
    console.assert(link.startsWith("https://wa.me/5534997741680?text="), "buildWaLink deve começar com URL wa.me");

    const decoded = decodeURIComponent(link.split("text=")[1] || "");
    console.assert(
      decoded.includes("Maria") && decoded.includes("Escova") && decoded.includes("11:00"),
      "Mensagem decodificada deve conter campos essenciais"
    );

    console.log("✅ Testes adicionais passaram (buildWaText, buildWaLink).");
  } catch (err) {
    console.warn("⚠️ Falha em testes adicionais:", err);
  }
})();